package com.gdu.app00.repository;

import org.springframework.stereotype.Repository;

import com.gdu.app00.domain.MemberDTO;

@Repository
public class MemberDAO {
//	private static final String NS = "mybatis.mapper.member.";
//	@Autowired
//	SqlSessionTemplate sqlSessionTemplate;
//	
//	public MemberDTO login(MemberDTO member) {
//		return sqlSessionTemplate.selectOne(NS+"memberLogin", member);
//	}
//	@Autowired
//	SqlSessionFactory factory;
//	
//	private static MemberDAO dao = new MemberDAO();
//	private MemberDAO() {
//		
//		try {
//			String resource = "mybatis/config/mybatis-config.xml";
//			InputStream in = Resources.getResourceAsStream(resource);
//			factory = new SqlSessionFactoryBuilder().build(in);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
//	
//	public static MemberDAO getInstance() {
//		return dao;
//	}
	
	public MemberDTO login(MemberDTO member) {
		
		return null;
	};
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
